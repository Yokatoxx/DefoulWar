using System;
using Unity.Behavior;
using UnityEngine;

[Serializable, Unity.Properties.GeneratePropertyBag]
[Condition(name: "HordeCheckDue", story: "HordeCheckDue [Self] & [lastHordeCheckTime]", category: "Conditions", id: "9bb2d24b67ad82d11a9b2fe86e4125fe")]
public partial class HordeCheckDueCondition : Condition
{
    // Blackboard variables (li�es depuis le Behavior Graph)
    [SerializeReference] public BlackboardVariable<GameObject> Self;
    [SerializeReference] public BlackboardVariable<float> lastHordeCheckTime;

    public override bool IsTrue()
    {
        // S�curit� : v�rifier que la variable Self est bien assign�e
        if (Self == null || Self.Value == null)
        {
            Debug.LogWarning("[HordeCheckDueCondition] 'Self' not set or null in Blackboard.");
            return false;
        }

        var agentGO = Self.Value;
        var agent = agentGO.GetComponent<EnemyAgent>();
        if (agent == null)
        {
            Debug.LogWarning("[HordeCheckDueCondition] EnemyAgent component missing on Self.");
            return false;
        }

        // Lecture du dernier check depuis le Blackboard
        float last = lastHordeCheckTime != null ? lastHordeCheckTime.Value : 0f;
        float interval = Mathf.Max(0.1f, agent.hordeCheckInterval); // S�curit� anti-division par z�ro

        return (Time.time - last) >= interval;
    }

    public override void OnStart()
    {
        // Pas besoin de logique ici, mais la m�thode doit exister
    }

    public override void OnEnd()
    {
        // Optionnel : nettoyage ou reset si n�cessaire
    }
}