using System;
using Unity.Behavior;
using UnityEngine;

[Serializable, Unity.Properties.GeneratePropertyBag]
[Condition(name: "NearbyUnassignedAtLeast", story: "NearbyUnassignedAtLeast", category: "Conditions", id: "4b2787bd0090eb64cb0c4d601f4f4f6d")]
public partial class NearbyUnassignedAtLeastCondition : Condition
{
    // Self is required to compute position
    public BlackboardVariable<GameObject> Self;
    // Threshold (value dragged from an Int blackboard variable or a constant variable)
    public BlackboardVariable<int> Threshold;

    public override bool IsTrue()
    {
        var agentGO = Self.Value;
        var agent = agentGO.GetComponent<EnemyAgent>();
        int count = HordeManager.Instance.CountUnassignedNearby(agentGO.transform.position, agent.hordeJoinRadius);
        return count >= Threshold.Value;
    }

    public override void OnStart() { }
    public override void OnEnd() { }
}
