using System;
using Unity.Behavior;
using UnityEngine;

[Serializable, Unity.Properties.GeneratePropertyBag]
[Condition(name: "SeesPlayerCondition", story: "SeesPlayerCondition [Self] & [seesPlayer] & [playerPosition]", category: "Conditions", id: "c9e2a862740e0a0ec5f722c92d7b3f92")]
public partial class SeesPlayerCondition : Condition
{
    public BlackboardVariable<GameObject> Self;
    public BlackboardVariable<bool> seesPlayer;
    public BlackboardVariable<Vector3> playerPosition;

    public override bool IsTrue()
    {
        var agentGO = Self.Value;
        var agent = agentGO.GetComponent<EnemyAgent>();

        bool result = agent.CheckSeesPlayer(out var p);
        seesPlayer.Value = agent.seesPlayer;
        playerPosition.Value = agent.playerPosition;
        return result;
    }

    public override void OnStart() { }
    public override void OnEnd() { }
}
