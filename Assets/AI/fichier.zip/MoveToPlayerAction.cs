using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "MoveToPlayer", story: "MoveToPlayer", category: "Action", id: "50a73acddc059bb272a61bf55fdebf8c")]
public partial class Action_MoveToPlayer : Action
{
    public BlackboardVariable<GameObject> Self;
    public BlackboardVariable<bool> seesPlayer;
    public BlackboardVariable<Vector3> playerPosition;

    protected override Status OnStart()
    {
        return Status.Running;
    }

    protected override Status OnUpdate()
    {
        var agentGO = Self.Value;
        var agent = agentGO.GetComponent<EnemyAgent>();

        agent.CheckSeesPlayer(out var p);
        seesPlayer.Value = agent.seesPlayer;
        playerPosition.Value = agent.playerPosition;

        agent.Action_MoveToPlayer_Local();

        return Status.Success;
    }

    protected override void OnEnd()
    {
    }
}

