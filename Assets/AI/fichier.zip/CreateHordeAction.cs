using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "CreateHorde", story: "CreateHorde", category: "Action", id: "c83a8c62b08d7b0092e69cfe45fd327a")]
public partial class Action_CreateHorde : Action
{
    public BlackboardVariable<GameObject> Self;
    public BlackboardVariable<int> hordeId;
    public BlackboardVariable<bool> isAlone;
    public BlackboardVariable<float> lastHordeCheckTime;

    protected override Status OnStart()
    {
        return Status.Running;
    }

    protected override Status OnUpdate()
    {
        var agentGO = Self.Value;
        var agent = agentGO.GetComponent<EnemyAgent>();

        var newH = HordeManager.Instance.CreateHorde(agentGO.transform.position, agent.hordeMax);
        newH.AddMember(agent);
        hordeId.Value = newH.Id;
        isAlone.Value = false;
        lastHordeCheckTime.Value = Time.time;
        return Status.Success;
    }

    protected override void OnEnd()
    {
    }
}

