using System;
using Unity.Behavior;
using UnityEngine;

[Serializable, Unity.Properties.GeneratePropertyBag]
[Condition(
    name: "NearbyUnassignedAtLeastAuto",
    story: "Returns true if there are enough unassigned agents near 'Self' to form a horde.",
    category: "Conditions",
    id: "5ae13cac328d3c7f190bf845780e4dcb"
)]
public partial class NearbyUnassignedAtLeastAutoCondition : Condition
{
    // Blackboard variable : le GameObject agent de r�f�rence
    [SerializeReference] public BlackboardVariable<GameObject> Self;

    public override bool IsTrue()
    {
        // --- V�rifications de s�curit� ---
        if (Self == null || Self.Value == null)
        {
            Debug.LogWarning("[NearbyUnassignedAtLeastAutoCondition] 'Self' is not set or null in Blackboard.");
            return false;
        }

        var agentGO = Self.Value;
        var agent = agentGO.GetComponent<EnemyAgent>();
        if (agent == null)
        {
            Debug.LogWarning("[NearbyUnassignedAtLeastAutoCondition] Missing EnemyAgent component on Self.");
            return false;
        }

        // --- V�rifie l'existence du HordeManager ---
        if (HordeManager.Instance == null)
        {
            Debug.LogWarning("[NearbyUnassignedAtLeastAutoCondition] HordeManager.Instance is null.");
            return false;
        }

        // --- Calcul de la condition ---
        int nearbyCount = HordeManager.Instance.CountUnassignedNearby(
            agentGO.transform.position,
            agent.hordeJoinRadius
        );

        return nearbyCount >= agent.hordeMinSize;
    }

    public override void OnStart() { }

    public override void OnEnd() { }
}