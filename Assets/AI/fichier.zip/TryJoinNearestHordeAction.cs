using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "TryJoinNearestHorde", story: "TryJoinNearestHorde", category: "Action", id: "878fc5586a81250b4f2ab52375f1609f")]
public partial class TryJoinNearestHorde : Action
{
    // Blackboard variables (obligatoires - link dans l'�diteur)
    public BlackboardVariable<GameObject> Self;
    public BlackboardVariable<int> hordeId;
    public BlackboardVariable<bool> isAlone;
    public BlackboardVariable<float> lastHordeCheckTime;

    protected override Status OnStart()
    {
        return Status.Running;
    }

    protected override Status OnUpdate()
    {
        // On suppose que Self et autres variables du Blackboard sont assign�es dans l'�diteur
        var agentGO = Self.Value;
        var agent = agentGO.GetComponent<EnemyAgent>();

        // Si l'agent a d�j� une horde locale => succ�s (synchroniser le blackboard)
        if (agent.hordeId != -1)
        {
            hordeId.Value = agent.hordeId;
            isAlone.Value = false;
            lastHordeCheckTime.Value = agent.lastHordeCheckTime;
            return Status.Success;
        }

        // Try to join nearest non-full horde
        var nearest = HordeManager.Instance.GetNearestJoinableHorde(agentGO.transform.position, agent.hordeJoinRadius);
        if (nearest != null)
        {
            nearest.AddMember(agent); // met � jour agent.hordeId via OnJoinedHorde
            hordeId.Value = nearest.Id;
            isAlone.Value = false;
            lastHordeCheckTime.Value = Time.time;
            return Status.Success;
        }

        // Check nearby unassigned to create a new horde
        int nearbyUnassigned = HordeManager.Instance.CountUnassignedNearby(agentGO.transform.position, agent.hordeJoinRadius);
        if (nearbyUnassigned >= agent.hordeMinSize)
        {
            var newH = HordeManager.Instance.CreateHorde(agentGO.transform.position, agent.hordeMax);
            newH.AddMember(agent);
            hordeId.Value = newH.Id;
            isAlone.Value = false;
            lastHordeCheckTime.Value = Time.time;
            return Status.Success;
        }

        // Else remain alone
        isAlone.Value = true;
        lastHordeCheckTime.Value = Time.time;
        return Status.Failure;
    }

    protected override void OnEnd()
    {
    }
}

